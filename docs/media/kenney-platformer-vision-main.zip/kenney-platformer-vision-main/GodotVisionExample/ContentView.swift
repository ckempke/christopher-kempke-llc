//  Created by Kevin Watters on 12/27/23.

import SwiftUI
import RealityKit
import GodotVision

struct ContentView: View {
    
    @StateObject private var godotVision = GodotVisionCoordinator()
    @State private var extraScale: Float = 1
    
    var scale: Float = 1
    var offset: simd_float3 = .zero

    var body: some View {
        GeometryReader3D { (geometry: GeometryProxy3D) in
            RealityView { content, attachments in
                
                let pathToGodotProject = "Godot_FPS" // The path to the folder containing the "project.godot" you wish Godot to load.
                
                // Initialize Godot
                let rkEntityGodotRoot = godotVision.setupRealityKitScene(content,
                                                                         volumeSize: VOLUME_SIZE,
                                                                         projectFileDir: pathToGodotProject,
                                                                         sharePlayActivityId: SHAREPLAY_ACTIVITY_ID)
                
                print("Godot scene root: \(rkEntityGodotRoot)")
                
                if let uiPanel = attachments.entity(for: "ui_panel") {
                    content.add(uiPanel)
                    uiPanel.position = .init(0, Float(VOLUME_SIZE.y / -2 + 0.1), Float(VOLUME_SIZE.z / 2 - 0.01))
                }
                
            } update: { content, attachments in
                // update called when SwiftUI @State in this ContentView changes. See docs for RealityView.
                // user can change the volume size from the default by selecting a different zoom level.
                // we watch for changes via the GeometryReader and scale the godot root accordingly
                let frame = content.convert(geometry.frame(in: .local), from: .local, to: .scene)
                let volumeSize = simd_double3(frame.max - frame.min)
                godotVision.changeScaleIfVolumeSizeChanged(volumeSize)
                if let uiPanel = attachments.entity(for: "ui_panel") {
                    // swiftui attachment also needs to be repositioned
                    uiPanel.position = .init(0, Float(volumeSize.y / -2 + 0.1), Float(volumeSize.z / 2 - 0.01))
                }
            } attachments: {
                Attachment(id: "ui_panel") {
                    VStack {
                        HStack {
                            Slider(value: $extraScale, in: 0.01...1.2) { value in
                                print(value)
                            }.onChange(of: extraScale) {
                                godotVision.extraScale = extraScale * scale
                            }.onChange(of: offset) {
                                godotVision.extraOffset = offset
                            }.onAppear {
                                godotVision.extraScale = extraScale * scale
                                godotVision.extraOffset = offset
                            }
                        }
                        HStack {
                            // A button to reload the current scene.
                            Button { godotVision.reloadScene() } label: {
                                Text("Reload")
                            }
                            
                            // Buttons for loading example scenes.
                            sceneButton(label: "Hello", resourcePath: "res://examples/hello/example_godot_vision_scene.tscn")
                            sceneButton(label: "Physics", resourcePath: "res://examples/physics_toy/physics_toy.tscn")
                            //sceneButton(label: "Materials", resourcePath: "res://tests/materials/materials.tscn")
                            sceneButton(label: "Skeletons", resourcePath: "res://examples/rigged_models/example_rigged_models.tscn")
                            sceneButton(label: "CSG", resourcePath: "res://examples/csg/csg.tscn")
                            sceneButton(label: "Multiplayer", resourcePath: "res://examples/multiplayer_example/multiplayer_example.tscn")
                        }

                    }.padding(36).frame(width: 700).glassBackgroundEffect()
                }
            }
            
            SkySphereView(sphereTextureName: "cloudy-sea")

        }
        .modifier(GodotVisionRealityViewModifier(coordinator: godotVision))
    }
        
    @ViewBuilder
    func sceneButton(label: String, resourcePath: String) -> some View {
        Button {
            godotVision.changeSceneToFile(atResourcePath: resourcePath)
        } label: {
            Text(label)
        }
    }
}

#Preview(windowStyle: .volumetric) {
    ContentView()
}
